
let buildings = JSON.parse(localStorage.getItem("buildings")) || [];
let selectedLatLng = "";

function saveBuilding(building) {
  buildings.push(building);
  localStorage.setItem("buildings", JSON.stringify(buildings));
  showMarkers();
}

function getLocation() {
  navigator.geolocation.getCurrentPosition(pos => {
    const lat = pos.coords.latitude;
    const lng = pos.coords.longitude;
    document.getElementById("latLng").value = `${lat}, ${lng}`;
    selectedLatLng = { lat, lng };
  });
}

document.getElementById("buildingForm").addEventListener("submit", e => {
  e.preventDefault();
  const building = {
    number: document.getElementById("buildingNumber").value,
    street: document.getElementById("streetName").value,
    owner: document.getElementById("ownerName").value,
    area: document.getElementById("area").value,
    floors: document.getElementById("floors").value,
    flatsPerFloor: document.getElementById("flatsPerFloor").value,
    flats: getFlatsDetails(),
    finishing: document.getElementById("finishingLevel").value,
    latLng: selectedLatLng,
    image: document.getElementById("propertyImage").files[0]?.name || ""
  };
  saveBuilding(building);
  alert("تم حفظ العقار ✅");
  resetForm();
});

function resetForm() {
  document.getElementById("buildingForm").reset();
  document.getElementById("flatsDetails").innerHTML = '';
  selectedLatLng = "";
}

function getFlatsDetails() {
  const details = [];
  document.querySelectorAll(".flat-detail").forEach(div => {
    const owner = div.querySelector(".flat-owner").value;
    const area = div.querySelector(".flat-area").value;
    details.push({ owner, area });
  });
  return details;
}

function addFlatDetail() {
  const div = document.createElement("div");
  div.className = "flat-detail";
  div.innerHTML = `
    <input type="text" placeholder="اسم مالك الشقة" class="flat-owner">
    <input type="number" placeholder="مساحة الشقة (م²)" class="flat-area">
  `;
  document.getElementById("flatsDetails").appendChild(div);
}

function exportToExcel() {
  let csv = "رقم الملك,الشارع,المالك,المساحة,عدد الأدوار,موقع,التشطيب\n";
  buildings.forEach(b => {
    csv += `${b.number},${b.street},${b.owner},${b.area},${b.floors},"${b.latLng.lat},${b.latLng.lng}",${b.finishing}\n`;
  });
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "حصر_العقارات.csv";
  link.click();
}

let map;
function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: 30.8, lng: 30.99 },
    zoom: 14
  });
  showMarkers();
}

function showMarkers() {
  if (!map) return;
  buildings.forEach(b => {
    if (b.latLng) {
      new google.maps.Marker({
        position: b.latLng,
        map: map,
        title: `الملك ${b.number}`
      });
    }
  });
}

window.onload = () => {
  initMap();
};
